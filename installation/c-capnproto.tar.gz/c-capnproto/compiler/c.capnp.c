#include "c.capnp.h"
/* AUTO GENERATED - DO NOT EDIT */
