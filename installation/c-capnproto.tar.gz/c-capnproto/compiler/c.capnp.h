#ifndef CAPN_C0183DD65FFEF0F3
#define CAPN_C0183DD65FFEF0F3
/* AUTO GENERATED - DO NOT EDIT */
#include <capnp_c.h>

#if CAPN_VERSION != 1
#error "version mismatch between capnp_c.h and generated code"
#endif


#ifdef __cplusplus
extern "C" {
#endif










#ifdef __cplusplus
}
#endif
#endif
